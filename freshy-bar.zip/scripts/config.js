export const API_URI = "https://jade-incongruous-ravioli.glitch.me/";

export const price = {
  Полуниця: 12,
  Банан: 12,
  Манго: 19,
  Ківі: 12,
  Маракуйя: 20,
  Яблуко: 8,
  "М'ята": 3,
  Біорозкладний: 5,
  Лід: 3,
  Пластиковий: 2,
  Лайм: 15,
};
